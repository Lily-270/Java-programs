package csc113;

public class ExecutiveSuite extends Suite{
        private boolean hasMeetingRoom;
        
        public ExecutiveSuite(boolean h,int roomNumber, int days) {
        	super(roomNumber,days);
        	hasMeetingRoom=h;
        }
        public double pricePerNight() {
        	return (numOfDays*price)+700;
        }
        public void displayInfo() {
        	super.displayInfo();
        	System.out.println("The suite has Meeting room: "+hasMeetingRoom);
        }
         
}
