package csc113;

public class LinkedList {
	//Attributes
private Resident head;
private Resident tail;
private String Name;
//Default constructor
public LinkedList() {
head = tail = null;
Name = "No Name";
}
//Parametrized constructor
public LinkedList(String name) {
head = tail = null;
Name = name;
}
//To check wether the list is empty
public boolean isEmpty() {
return head == null;
}
//To add objects at front in the list
public void insertAtFront(Resident newResident) {
    if (isEmpty()) {
        head = tail = newResident;
    } else {
        newResident.setNext(head);
        head = newResident;
    }
}
//Getter
public Resident getHead() {
    return head;
}
}
