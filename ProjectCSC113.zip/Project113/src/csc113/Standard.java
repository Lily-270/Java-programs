package csc113;

public class Standard extends Room{
	
      private boolean hasView;
      //Parametrized constructor
      public Standard(int roomNumber, int days) {
    	    super(roomNumber, days);
    	    hasView = false;
    	}
      
	public void displayInfo() {
		System.out.println("-----------------------");
		System.out.println("Room number: "+Rnum
				+"\nNumber of days: "+numOfDays
				+"\nExtra beds: "+hasExtraBed
				+"\nRoom's bill: "+totalBill()+" SAR"
				+"\nThe room has view: "+hasView);
		System.out.println("-----------------------");
	}
	public double priceExtraBeds() {
	    if (hasExtraBed) {
	        return 0.25 * ExtraBedPrice;
	    }
	    return 0;
	}
	public double pricePerNight() {
		return (numOfDays*price)+250;
	}
	public void setHasView(boolean b) {
		hasView=b;
	}
	}


