package csc113;

public interface GYM {
    double gymSubPerMonth();
    String viewSub(); // Change this from void to String
}
