package csc113;
import java.util.*;
import javax.swing.SwingUtilities;
import java.io.*;
public class TestHotel {
	public static void main(String[] args) throws IOException, ClassNotFoundException,EOFException{
		
		Scanner s=new Scanner(System.in);
	    int task;
	    //We instantiate objects to invoke the methods in these classes
	    JLA_Hotel h=new JLA_Hotel();
	    Resident r = null;
	    Visitor vs=null;
	    Suite s1=null;
	    Standard d1=null;
	    ExecutiveSuite es=null;   
	    System.out.println("Welcome to JLA Hotel!");
	    
        ObjectInputStream in = null;
        
        SwingUtilities.invokeLater(() -> {
            WelcomeFrame frame = new WelcomeFrame();
            frame.setVisible(true); // This makes the window appear!
        });

        try {
            in = new ObjectInputStream(new FileInputStream("Reservation.data"));
            //Reading all data at once because the number of objects added is unknown
            while (true) {
                Object obj = in.readObject();
                h.addObj(obj); 
            }

        } catch (EOFException e) {
        	System.out.println(e.getMessage());
        } catch (FileNotFoundException e) {
        	System.out.println(e.getMessage());
        }
        
		do {
			//Menu 
			 System.out.println("\n1. Check in\n2. Reserve a room\n3. Cancel reservation\n"
			    + "4. Gym subscribtion\n5. View booking\n"
			     + "6. Exit menu");
			      System.out.println("Enter a task number from the menu: ");
			        task = s.nextInt();
			        //Object Reading Stream - to read previous data stored in the file
			        switch(task){    
			        //This case adds the resident information + it invokes the method addResident
			        case 1:{
			        	System.out.println("Enter your information: ");
			        	System.out.println("Enter your name:");
        	            s.nextLine();
        	            String n=s.nextLine();
			        	String p=null;
			        	while(true) {
			        	//Handles the PhoneNumberExp and the InputMismatchException if occured
                        try {
    			        	    System.out.println("Enter your ID:");
    			        	    int i=s.nextInt();
    				        	System.out.println("Enter your phone number: (The number must be out of 10 digits)");
    				        	String tester=s.next();
                        	    boolean b=h.isValidPhoneNum(tester);
                        	    if(b) {
			        			p=tester;
			        		    r=new Resident(n,i,p);
			        		    h.addResident(r);
			        		    h.addObj(r);
			        		    //Object Writing Stream
			        		    ObjectOutputStream out = new ObjectOutputStream(
			        		    	    new FileOutputStream("Reservation.data"));

			        		    	for (int j = 0; j < h.count; j++) {
			        		    	    out.writeObject(h.records[j]);
			        		    	}

			        		    	out.close();
					        	System.out.println("Your info is added successfully!");
					        	break;
                        	    }
                        }
                        //Unchecked exception
                        catch(InputMismatchException e) {                     	
                        	System.out.println("Invalid input!");
                        	System.out.println("Try again"); 
                        	s.nextLine();
                        }
                        //Checked user defined exception
                        catch(PhoneNumberExp e) {
                        	System.out.println(e.getMessage());
                        	System.out.println("Try again");                      	
			        	}
			        	}
			        			
			        }
			        break;
			        case 2:{
			        	//This case reserve a room in the array + it uses methods addRoom and searchRoomRecursive
			        	if(r==null) {
			        		//To validate if the resident did check in
			        		System.out.println("You must check in first!");
			        	}
			        	else {

			        	    System.out.println("Select Suite or Standard or Executive Suite:");
			        	    System.out.println("For Suite enter 's'");
			        	    System.out.println("For Standard enter 'd'");
			        	    System.out.println("For Executive Suite enter 'x'");
			        	    String x = s.next();	
			        	    while(!(x.equalsIgnoreCase("s") || x.equalsIgnoreCase("d")||x.equalsIgnoreCase("x"))) {
			        	    	System.out.println("You must choose either s (Suite) or d (Standard) or x(Executive Suite)");
                            	x = s.next();
			        	    }
			        	    int num;

			        	    //Room number validation loop
			        	    while (true) {

			        	        System.out.println("Pick a room number (1-99): ");
			        	        num = s.nextInt();

			        	        if (num < 1 || num > 99) {
			        	            System.out.println("Invalid room number! Try again.");
			        	            continue;
			        	        }

			        	        if (h.searchRoomRecursive(num)) {
			        	            System.out.println("Room " + num + " is already reserved!");
			        	        }
			        	        else {
			        	            break;
			        	        }
			        	    }
			        	    System.out.println("How many days you will stay in the hotel:");
			        	    int days = s.nextInt();
			        	    // Create the correct room type
			        	    if ((x.equalsIgnoreCase("s"))) {
			        	    	//We pass the object with composition
			        	    	s1=new Suite(num, days);
			        	        h.addRoom(s1,r.getId());
			        	        h.addObj(s1);
			        	        ObjectOutputStream out = new ObjectOutputStream(
			        	        	    new FileOutputStream("Reservation.data"));

			        	        	for (int i = 0; i < h.count; i++) {
			        	        	    out.writeObject(h.records[i]);
			        	        	}

			        	        	out.close();
			        	        System.out.println("Would you like a jacuzzi: - Please choose Yes or No");
			        	        char j=s.next().charAt(0);
			        	        if(j == 'Y' || j=='y') {
			        	        	s1.setHasJacuuzi(true);
			        	        }
			        	        else if(j=='N'|| j=='n') {
			        	        	s1.setHasJacuuzi(false);
			        	        }
			        	        else 
			        	        	System.out.println("Because you entered other than yes or no you have no jacuzzi!");
				        	    System.out.println("Would you like extra beds \n- Please choose Yes or No (You will be charged only for the first bed you order):");
				        	    char e=s.next().charAt(0);
			        	        if(e == 'Y' || e=='y') {
			        	        	s1.setHasExtraBed(true);
			        	        }
			        	        else if(e=='N'|| e=='n') {
			        	        	s1.setHasExtraBed(false);
			        	        }
			        	        else
			        	        	System.out.println("Because you entered other than yes or no you have no extra beds!");
			        	        
			        	        System.out.println("Room " + num + " is reserved successfully!");
			        	    }
			        	    else if(x.equalsIgnoreCase("d")) {
			        	    	d1=new Standard(num, days);
			        	    	//We pass the object with composition
			        	        h.addRoom(d1,r.getId());
			        	        h.addObj(d1);
			        	        ObjectOutputStream out = new ObjectOutputStream(
			        	        	    new FileOutputStream("Reservation.data"));

			        	        	for (int i = 0; i < h.count; i++) {
			        	        	    out.writeObject(h.records[i]);
			        	        	}

			        	        	out.close();
			        	        System.out.println("Would you like a View over the beach: - Please choose Yes or NO");
			        	        char v=s.next().charAt(0);
			        	        if(v == 'Y' || v=='y') {
			        	        	d1.setHasView(true);
			        	        }
			        	        else if(v=='N'|| v=='n') {
			        	        	d1.setHasView(false);
			        	        }
			        	        else
			        	        	System.out.println("Because you entered other than yes or no you have no view over the beach!");
			        	        System.out.println("Would you like extra beds (You will be charged only for the first bed you order:");
				        	    char e=s.next().charAt(0);
			        	        if(e == 'Y' || e=='y') {
			        	        	d1.setHasExtraBed(true);
			        	        }
			        	        else if(e=='N'|| e=='n') {
			        	        	d1.setHasExtraBed(false);
			        	        }
			        	        else
			        	        	System.out.println("Because you entered other than yes or no you have no extra beds!");
			        	      
			        	        System.out.println("Room " + num + " is reserved successfully!");
			        	    }
			        	    else {
			        	    	s1=new Suite(num,days);
			        	        System.out.println("Would you like a jacuzzi: - Please choose Yes or No");
			        	        char j=(s.next()).charAt(0);
			        	        boolean jac=false;
			        	        if(j == 'Y' || j=='y') {
			        	        	s1.setHasJacuuzi(true);
			        	        	jac=true;
			        	        }
			        	        else if(j=='N'|| j=='n') {
			        	        	s1.setHasJacuuzi(false);
			        	        }
			        	        else 
			        	        	System.out.println("Because you entered other than yes or no you have no jacuzzi!");
				        	    System.out.println("Would you like extra beds \n- Please choose Yes or No (You will be charged only for the first bed you order):");
				        	    char e=(s.next()).charAt(0);
				        	    boolean bed=false;
			        	        if(e == 'Y' || e=='y') {
			        	        	s1.setHasExtraBed(true);
			        	        	bed=true;
			        	        }
			        	        else if(e=='N'|| e=='n') {
			        	        	s1.setHasExtraBed(false);
			        	        }		        	        	
			        	        else
			        	        	System.out.println("Because you entered other than yes or no you have no extra beds!");
			        	            System.out.println("Would you like a meeting room ? Please choose Yes or No");
			        	            char mRoom=(s.next()).charAt(0);
			        	            if(mRoom == 'Y' || mRoom=='y') {
			        	            	es=new ExecutiveSuite(true,num,days);
				        	        	h.addRoom(es,r.getId());
				        	        	h.addObj(es);
				        	        	ObjectOutputStream out = new ObjectOutputStream(
				        	        		    new FileOutputStream("Reservation.data"));

				        	        		for (int i = 0; i < h.count; i++) {
				        	        		    out.writeObject(h.records[i]);
				        	        		}

				        	        		out.close();
				        	        	es.setHasExtraBed(bed);
				        	        	es.setHasJacuuzi(jac);
				        	        }
				        	        else if(mRoom=='N'|| mRoom=='n') {
				        	        	es=new ExecutiveSuite(false,num,days);
				        	        	h.addRoom(es,r.getId());
				        	        	h.addObj(es);
				        	        	ObjectOutputStream out = new ObjectOutputStream(
				        	        		    new FileOutputStream("Reservation.data"));

				        	        		for (int i = 0; i < h.count; i++) {
				        	        		    out.writeObject(h.records[i]);
				        	        		}

				        	        		out.close();
				        	        	es.setHasExtraBed(bed);
				        	        	es.setHasJacuuzi(jac);
				        	        }
				        	        else {
				        	        	System.out.println("Because you entered other than yes or no you have no meeting room!");
				        	        }
			        	            
			        	            System.out.println("Room " + num + " is reserved successfully!");
			        	        }
			        	    
			        }
			       
			        }
			        break;
			        case 3:{
			        	//This case removes the room from the array + it uses method removeRoom
			        	if(r==null) {
			        		System.out.println("You must check in first!");
			        	}
			        	else {
			        	System.out.println("Enter the number of room you want to cancel:");
			        	int nR=s.nextInt();
			        	boolean b=h.removeRoom(nR);
			        	if(b) 
			        		System.out.println("The room reservation is cancelled!");
			        	else
			        		System.out.println("Room "+nR+" is not reserved yet!");		
			        	}
			        }
			        break;
			        case 4:{
			        	//This case invokes the method viewSub for resident and non resident gym info
			        	if(r==null) {
			        		
			        		System.out.println("Enter your information: ");
			        		
				        	System.out.println("Enter your name:");
				        	s.nextLine();
				        	String n=s.nextLine();
				        	System.out.println("Enter your age:");
				        	int a=s.nextInt();
				        	System.out.println("Enter your gender:");
				        	 char g=(s.next()).charAt(0);

						        	vs=new Visitor(n,g,a);
						        	System.out.println("Your info is added successfully!\n");
						        	vs.viewSub();
			        	}
			        	else {
			        		r.viewSub();
			        	}
			        }
			        break;    
			        case 5:{
			        	//This case display all the info regarding the resident and the room they reserved
			        	System.out.println("Enter your name:");
			        	s.nextLine();
			        	String n=s.nextLine();
			        	System.out.println("Enter your room number:");
			        	int nR=s.nextInt();
			        	h.viewBooking(n, nR);
			        }
			        break;
			        case 6:{
			        	System.out.println("Thanks for using JLA Hotel system!");
			        }
			        break;
			        default: {
			        	System.out.println("Invalid choice select 1-6");
			        }
			        }        
		}while(task !=6);
		s.close();
	}
	}

