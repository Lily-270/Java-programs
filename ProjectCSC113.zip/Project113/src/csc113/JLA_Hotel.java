package csc113;

public class JLA_Hotel {
	
	private int NumOfR;
	private int NumOfG;
	private Room[] reservedRooms;
	private LinkedList HResidents;
	Object[] records = new Object[100]; // fixed size
	int count = 0;
	//Default constructor
	public JLA_Hotel() {
		NumOfR=0;
		NumOfG=0;
		reservedRooms=new Room[100];
		HResidents= new LinkedList("JLA Hotel Guest List");
	}
	// checked Exception throwing method
	public boolean isValidPhoneNum(String tester)  throws PhoneNumberExp{
		if(tester.length()!= 10) {
			throw new PhoneNumberExp("Invalid number");		
   }
   for(int x=0;x<tester.length();x++) {
	if(!(Character.isDigit(tester.charAt(x)))) {
		throw new PhoneNumberExp("Invalid number");
	}
   }
     return true;
	}
	//Methods for reservedRooms
	//AddRoom - it checks for available rooms to reserve and links the room with the id!
	public void addRoom(Room r,long id) {
	    if (NumOfR < reservedRooms.length) {
	    	r.setOwnerId(id);
	        reservedRooms[NumOfR] = r;
	        NumOfR++;
	    } else {
	        System.out.println("No empty rooms available!");
	    }
	}
	
	//We add a helper method because recursion needs an index parameter
	public boolean searchRoomRecursive(int n) {
	    return searchHelper(n, 0); // Start searching from index 0
	}
    //Recursive method
	private boolean searchHelper(int n, int index) {
	    // Base Case 1: We've checked all reserved rooms and found nothing
	    if (index >= NumOfR) {
	        return false;
	    }

	    //Base Case 2: We found the room number!
	    if (reservedRooms[index].getRnum() == n) {
	        return true;
	    }

	    //Recursive Step: Search the next index
	    return searchHelper(n, index + 1);
	}
	//This method deletes the room by replace!
	public boolean removeRoom(int n) {
		for(int i=0;i<NumOfR;i++) {
			if(reservedRooms[i].getRnum()==n) {
				reservedRooms[i]=reservedRooms[NumOfR-1];
				reservedRooms[NumOfR--]=null;
				return true;
			}
		}
		return false;
	}
	//Adds an object of either resident or room to an array records[]
	public void addObj(Object obj) {
        if (count < records.length) {
            records[count] = obj;
            count++;
        }

        if (obj instanceof Resident) {
            Resident r = (Resident) obj;
            System.out.println("Resident added: " + r.getName());
        } 
        else if (obj instanceof Room) {
            Room room = (Room) obj;
            System.out.println("Room added: " + room.getRnum());
        }
    }
	//Display
	public void viewBooking(String name, int roomNum) {

	    Room foundRoom = null;
	    Resident owner = null;

	    // 1. Find the room
	    for (int i = 0; i < count; i++) {

	        Object obj = records[i];

	        if (obj instanceof Room) {
	            Room room = (Room) obj;

	            if (room.getRnum() == roomNum) {
	                foundRoom = room;
	                break;
	            }
	        }
	    }

	    if (foundRoom == null) {
	        System.out.println("Room " + roomNum + " not found or not reserved.");
	        return;
	    }

	    // 2. Find the owner of that room
	    Resident current = HResidents.getHead();
        while (current != null) {
            if (current.getId() == foundRoom.getOwnerId()) {
                owner = current;
                break;
            }
            current = current.getNext();
        }

        if (owner == null) {
            System.out.println("Room is reserved but owner not found in guest list.");
            return;
        }

        if (!owner.getName().equalsIgnoreCase(name)) {
            System.out.println("This room belongs to: " + owner.getName());
            return;
        }

        System.out.println("Resident Details:");
        System.out.println(owner.viewSub());
        System.out.println("Room Details:");
        foundRoom.displayInfo();
	}
	
	//Method for Resident array
	//This method is for adding a resident by aggregation
	public void addResident(Resident G) {
        HResidents.insertAtFront(G);
        NumOfG++;
    }
	//Getter method
	public int getRnum() {
		 return NumOfR;
	 }

}
