package csc113;

public class Visitor implements GYM {

    private String name;
    private char gender;
    private int age;
    
    public Visitor(String n, char g, int a) {
        name = n;
        gender = g;
        age = a;
    }

    public double gymSubPerMonth() {
        return 1000;
    }

    // CHANGED TO STRING RETURN
    public String viewSub() {
        return "-----------------------\n" +
               "Visitor Information:\n" +
               "Name: " + name + "\n" +
               "Gender: " + gender + "\n" +
               "Age: " + age + "\n" +
               "Gym subscription fees: " + gymSubPerMonth() + " SAR per month.\n" +
               "-----------------------";
    }

    public String getName() { return name; }
    public char getGender() { return gender; }
    public int getAge() { return age; }
}