package csc113;

public class Suite extends Room{
	
private boolean hasJacuzzi=false;
//Parametrized constructor
public Suite(int roomNumber, int days) {
    super(roomNumber, days);
}
public void displayInfo() {
	System.out.println("-----------------------");
	System.out.println("Room number: "+Rnum
			+"\nNumber of days: "+numOfDays
			+"\nThe room has a jacuzzi: "+hasJacuzzi
			+"\nExtra beds: "+hasExtraBed
			+"\nRoom's bill: "+totalBill()+" SAR");
	System.out.println("-----------------------");
}
public double priceExtraBeds() {
    if (hasExtraBed) {
        return 0.5 * ExtraBedPrice;
    }
    return 0;
}
public double pricePerNight() {
	return (numOfDays*price)+500;
}
public void setHasJacuuzi(boolean b) {
	hasJacuzzi=b;
}
}
