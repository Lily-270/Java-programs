package csc113;
import java.io.*;

public class Resident implements GYM, Serializable {
    private String name;
    private long id;
    private String phoneNum;
    private Resident next;
    private static final long serialVersionUID = -4696187141834165642L;

    public Resident(String n, long i, String p) {
        this.name = n;
        this.id = i;
        this.phoneNum = p;
        next=null;
    }

    public Resident getNext() { return next; }
    public void setNext(Resident next) { this.next = next; }
    
    public double gymSubPerMonth() { return 700.0; }

    
    public String viewSub() {
        return "--- RESIDENT GYM PASS ---\n" +
               "Name: " + name + "\n" +
               "ID: " + id + "\n" +
               "Phone: " + phoneNum + "\n" +
               "Monthly Fee: " + gymSubPerMonth() + " SAR";
    }
    // Getters
    public void setName(String n) { name = n; }
    public void setId(long i) { id = i; }
    public void setPhoneNum(String p) { phoneNum = p; }

    public String getName() { return name; }
    public long getId() { return id; }
    public String getPhoneNum() { return phoneNum; }
}