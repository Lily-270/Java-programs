package csc113;
//User defined exception!
public class PhoneNumberExp extends Exception{
      public PhoneNumberExp(String message) {
    	  super(message);
      }
}
