package csc113;
import java.io.*;
public abstract class Room implements Serializable{
	
	protected long ownerId; //For linking the guest with the room
	protected final double price=250;
	protected int Rnum;
	protected int numOfDays;
	protected boolean hasExtraBed=false;
	protected final int ExtraBedPrice=150;
	//Parametrized constructor
	public Room(int roomNumber, int days) {
        this.Rnum = roomNumber;
        this.numOfDays = days;
    }
	//Polymorphism methods 
	public double pricePerNight() {
		return numOfDays*price;
	}
	public void displayInfo() {
		System.out.println("-----------------------");
		System.out.println("Room number: "+Rnum
				+"\nNumber of days: "+numOfDays
				+"\nRoom's bill: "+totalBill());
		System.out.println("-----------------------");
	}
	//This is abstract method
	 public abstract double priceExtraBeds();
	 //For calculating total price of the room
	 public double totalBill() {
		 return pricePerNight()+priceExtraBeds();
	 }
	 //Setters
	 public void setRnum(int n) {
		 Rnum=n;
	 }
	 public void setDays(int d) {
		 numOfDays=d;
	 }
	 public void setHasExtraBed(boolean b) {
		 hasExtraBed=b;
	 }
	public void setOwnerId(long id) { 
			this.ownerId = id; 
	 }
	 //Getters
	 public int getRnum() {
		 return Rnum;
	 }
	 public int getDays() {
		 return numOfDays;
	 }
	public long getOwnerId() { 
			return ownerId; 
	}
	 
}
