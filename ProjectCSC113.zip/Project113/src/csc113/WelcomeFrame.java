package csc113;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

// Main Welcome Window

public class WelcomeFrame extends JFrame {
    private static final int FRAME_WIDTH = 600;
    private static final int FRAME_HEIGHT = 750;

    public WelcomeFrame() {
        setTitle("JLA Hotel");
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JLabel welcomeLabel = new JLabel("Welcome to JLA Hotel!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Serif", Font.BOLD, 28));
        add(welcomeLabel, BorderLayout.NORTH);

        //JLA hotel image 
            String path = "C:\\Users\\lilya\\Downloads\\ChatGPT Image Mar 1, 2026, 05_04_34 PM.png";
            ImageIcon icon = new ImageIcon(path);
            Image scaledImg = icon.getImage().getScaledInstance(550, 400, Image.SCALE_SMOOTH);
            add(new JLabel(new ImageIcon(scaledImg)), BorderLayout.CENTER);

        JButton bookButton = new JButton("Book Now");
        bookButton.setPreferredSize(new Dimension(150, 50));
        //Action listner
        bookButton.addActionListener(e -> {
            this.dispose();
            new MenuWindow().setVisible(true);
        });

        JPanel btnPanel = new JPanel();
        btnPanel.add(bookButton);
        add(btnPanel, BorderLayout.SOUTH);
        getContentPane().setBackground(Color.LIGHT_GRAY);
    }
}

//Menu Window Frame
class MenuWindow extends JFrame {
    //We created objects in order to send the information to them
    public static JLA_Hotel hotel = new JLA_Hotel();
    private static Resident currentResident = null;
    private static boolean hasRegistered = false;
    
    private JTextField inputLine;
    private JTextArea textArea;

    public MenuWindow() {
        setTitle("Main Menu");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        textArea = new JTextArea();
        textArea.setText("Choose from the menu below:\n\n1. Check in\n2. Reserve a room\n3. Cancel Reservation\n4. Gym Subscription\n5. View Booking\n6. Exit");
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.BOLD, 16));
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Enter Task Number:"));
        inputLine = new JTextField(10);
        inputPanel.add(inputLine);

        JButton enterButton = new JButton("Enter");
        //Action listner
        enterButton.addActionListener(e -> handleChoice(inputLine.getText()));
        inputPanel.add(enterButton);
        add(inputPanel, BorderLayout.SOUTH);
    }
   //This method handles the differnt choices numbers opening the window associated with each choice!
    private void handleChoice(String choice) {
        switch (choice) {
            case "1":
                this.dispose();
                new Case1Window().setVisible(true);
                break;
            case "2":
                if (!hasRegistered) {
                    JOptionPane.showMessageDialog(this, "You must check in (Option 1) first!");
                } else {
                    this.dispose();
                    new Case2Window().setVisible(true);
                }
                break;
            case "3":
                this.dispose();
                new case3Window().setVisible(true);
                break;
            case "4":
                handleGymChoice();
                break;
            case "5":
                if (hasRegistered) {
                    this.dispose();
                    new Case5Window(currentResident).setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "No booking found. Please register first.");
                }
                break;
            case "6":
                System.exit(0);
                break;
            default:
                JOptionPane.showMessageDialog(this, "Invalid choice, try again.");
        }
    }
   //Opens a dialog message window 
    private void handleGymChoice() {
        int response = JOptionPane.showConfirmDialog(this, "Are you a resident?", "Gym Access", JOptionPane.YES_NO_OPTION);
        this.dispose();
        new Case4Window(response == JOptionPane.YES_OPTION).setVisible(true);
    }

    //Sends the new data to the resident object
    public static void setResident(Resident r) {
        currentResident = r;
        hasRegistered = true;
        hotel.addResident(r);
        hotel.addObj(r);
        saveToFile();
    }
   //To save the changes in the file
    public static void saveToFile() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("Reservation.data"))) {
            for (int i = 0; i < hotel.count; i++) {
                out.writeObject(hotel.records[i]);
            }
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }

    public static Resident getCurrentResident() { return currentResident; }
}
// Registeration window 
class Case1Window extends JFrame {
    private JTextField nameField, idField, phoneField;

    public Case1Window() {
        setTitle("Registration");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel layoutPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        layoutPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        layoutPanel.add(new JLabel("Name:"));
        nameField = new JTextField();
        layoutPanel.add(nameField);

        layoutPanel.add(new JLabel("ID:"));
        idField = new JTextField();
        layoutPanel.add(idField);

        layoutPanel.add(new JLabel("Phone:"));
        phoneField = new JTextField();
        layoutPanel.add(phoneField);

        add(layoutPanel, BorderLayout.CENTER);

        JButton regBtn = new JButton("Register");
        regBtn.addActionListener(e -> {
            try {
                String name = nameField.getText();
                long id = Long.parseLong(idField.getText());
                String phone = phoneField.getText();

                //validation
                if (MenuWindow.hotel.isValidPhoneNum(phone)) {
                    Resident res = new Resident(name, id, phone);
                    MenuWindow.setResident(res);
                    JOptionPane.showMessageDialog(this, "Registered successfully!");
                    this.dispose();
                    new MenuWindow().setVisible(true);
                }
            } catch (PhoneNumberExp ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid ID format.");
            }
        });
        add(regBtn, BorderLayout.SOUTH);
    }
}
//Room reservation window
class Case2Window extends JFrame {
    private JTextField roomNum, stayDays;

    public Case2Window() {
        setTitle("Room Reservation");
        setSize(400, 350);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(6, 1, 10, 10));

        JRadioButton opt1 = new JRadioButton("Suite");
        JRadioButton opt2 = new JRadioButton("Standard");
        JRadioButton opt3 = new JRadioButton("Executive Suite");
        ButtonGroup group = new ButtonGroup();
        group.add(opt1); group.add(opt2); group.add(opt3);

        add(new JLabel(" Select Room Type:", SwingConstants.CENTER));
        add(opt1); add(opt2); add(opt3);

        JPanel p = new JPanel(new GridLayout(2, 2));
        p.add(new JLabel(" Room number: 1-99")); roomNum = new JTextField(); p.add(roomNum);
        p.add(new JLabel(" Days:")); stayDays = new JTextField(); p.add(stayDays);
        add(p);

        JButton okBtn = new JButton("Next");
      //Action listner
        okBtn.addActionListener(e -> {
                int n = Integer.parseInt(roomNum.getText());
                int d = Integer.parseInt(stayDays.getText());

                if (MenuWindow.hotel.searchRoomRecursive(n)) {
                    JOptionPane.showMessageDialog(this, "Room already reserved!");
                    return;
                }
                this.dispose();
                if (opt1.isSelected()) new SuiteOptionsFrame(n, d).setVisible(true);
                else if (opt2.isSelected()) new StandardOptionsFrame(n, d).setVisible(true);
                else if (opt3.isSelected()) new ExecutiveOptionsFrame(n, d).setVisible(true);
                else JOptionPane.showMessageDialog(this, "Select a room type.");
                
        });
        add(okBtn);      
}
}
//Suite reservation window
class SuiteOptionsFrame extends JFrame {
    public SuiteOptionsFrame(int rNum, int days) {
        setTitle("Suite Specs");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 1));

        JCheckBox jac = new JCheckBox("Include Jacuzzi");
        JCheckBox bed = new JCheckBox("Extra Bed");
        add(new JLabel("Customize your Suite:", SwingConstants.CENTER));
        add(jac); add(bed);

        JButton resBtn = new JButton("Reserve");
      //Action listner
        resBtn.addActionListener(e -> {
            Suite s = new Suite(rNum, days);
            s.setHasJacuuzi(jac.isSelected());
            s.setHasExtraBed(bed.isSelected());
            
            MenuWindow.hotel.addRoom(s, MenuWindow.getCurrentResident().getId());
            MenuWindow.hotel.addObj(s);
            MenuWindow.saveToFile();
            
            JOptionPane.showMessageDialog(this, "Suite " + rNum + " Reserved!");
            this.dispose();
            new MenuWindow().setVisible(true);
        });
        add(resBtn);
    }
}
//Standard room reservation 
class StandardOptionsFrame extends JFrame {
    public StandardOptionsFrame(int rNum, int days) {
        setTitle("Standard Room Specifications");
        setSize(400, 350);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel(new GridLayout(4, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel label = new JLabel("Customize your Standard Room:", SwingConstants.CENTER);
        label.setFont(new Font("SansSerif", Font.BOLD, 14));
        panel.add(label);

        JCheckBox viewCheck = new JCheckBox("View on the beach");
        JCheckBox bedCheck = new JCheckBox("Extra bed");
        
        panel.add(viewCheck);
        panel.add(bedCheck);
        add(panel, BorderLayout.CENTER);

        JButton reserveBtn = new JButton("Confirm Reservation");
        reserveBtn.setPreferredSize(new Dimension(100, 40));
      //Action listner
        reserveBtn.addActionListener(e -> {
          
            Standard std = new Standard(rNum, days);
            std.setHasView(viewCheck.isSelected());
            std.setHasExtraBed(bedCheck.isSelected());

            
            MenuWindow.hotel.addRoom(std, MenuWindow.getCurrentResident().getId());
            MenuWindow.hotel.addObj(std);
            MenuWindow.saveToFile();

            JOptionPane.showMessageDialog(this, "Standard Room " + rNum + " Reserved Successfully!");
            this.dispose();
            new MenuWindow().setVisible(true);
        });

        add(reserveBtn, BorderLayout.SOUTH);
    }
}
//Executive suite reservation
class ExecutiveOptionsFrame extends JFrame {
    public ExecutiveOptionsFrame(int rNum, int days) {
        setTitle("Executive Suite Specifications");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel label = new JLabel("Customize your Executive Suite:", SwingConstants.CENTER);
        label.setFont(new Font("SansSerif", Font.BOLD, 14));
        panel.add(label);

        JCheckBox meetingCheck = new JCheckBox("Include Meeting Room");
        JCheckBox jacCheck = new JCheckBox("Include Jacuzzi");
        JCheckBox bedCheck = new JCheckBox("Extra bed");

        panel.add(meetingCheck);
        panel.add(jacCheck);
        panel.add(bedCheck);
        add(panel, BorderLayout.CENTER);

        JButton reserveBtn = new JButton("Confirm Reservation");
        //Action listner
        reserveBtn.addActionListener(e -> {
            
            ExecutiveSuite exec = new ExecutiveSuite(meetingCheck.isSelected(), rNum, days);
            exec.setHasJacuuzi(jacCheck.isSelected());
            exec.setHasExtraBed(bedCheck.isSelected());

           
            MenuWindow.hotel.addRoom(exec, MenuWindow.getCurrentResident().getId());
            MenuWindow.hotel.addObj(exec);
            MenuWindow.saveToFile();

            JOptionPane.showMessageDialog(this, "Executive Suite " + rNum + " Reserved Successfully!");
            this.dispose();
            new MenuWindow().setVisible(true);
        });

        add(reserveBtn, BorderLayout.SOUTH);
    }
}
//Cancelling reservation window
class case3Window extends JFrame {
    private Container contentPane;
    private JPanel panel = new JPanel();

    public case3Window() {
        setTitle("Cancel Reservation");
        setSize(400, 200); 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());

        
        JLabel label = new JLabel("Would you like to cancel the reservation?", SwingConstants.CENTER);
        contentPane.add(label, BorderLayout.CENTER);

        
        JButton YesBtn = new JButton("Yes");
        YesBtn.setPreferredSize(new Dimension(100, 40));
        JButton NoBtn = new JButton("No");
        NoBtn.setPreferredSize(new Dimension(100, 40));

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(YesBtn);
        buttonPanel.add(NoBtn);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);
      //Action listner
        YesBtn.addActionListener(e -> {
            
            JOptionPane.showMessageDialog(this, "Reservation Cancelled Successfully.");
            this.dispose();
            new MenuWindow().setVisible(true); 
        });

        NoBtn.addActionListener(e -> {
            this.dispose();
            new MenuWindow().setVisible(true); 
        });
    }
}
//Gym subscribtion info window
class Case4Window extends JFrame {
    private JTextField nameF, extraF1, extraF2; 

    public Case4Window(boolean isResident) {
        setTitle("Gym Subscription");
        setSize(400, 350);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(0, 2, 10, 10));
        form.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        form.add(new JLabel("Name:"));
        nameF = new JTextField();
        form.add(nameF);

        if (isResident) {
            form.add(new JLabel("ID Number:"));
            extraF1 = new JTextField();
            form.add(extraF1);
            form.add(new JLabel("Phone Number:"));
            extraF2 = new JTextField();
            form.add(extraF2);
        } else {
            form.add(new JLabel("Gender (M/F):"));
            extraF1 = new JTextField();
            form.add(extraF1);
            form.add(new JLabel("Age:"));
            extraF2 = new JTextField();
            form.add(extraF2);
        }

        add(form, BorderLayout.CENTER);

        JButton viewBtn = new JButton("View Subscription");
        //Action listner
        viewBtn.addActionListener(e -> {
            String info;
            try {
                if (isResident) {
                    Resident r = new Resident(nameF.getText(), Long.parseLong(extraF1.getText()), extraF2.getText());
                    info = r.viewSub();
                } else {
                    Visitor v = new Visitor(nameF.getText(), extraF1.getText().charAt(0), Integer.parseInt(extraF2.getText()));
                    info = v.viewSub();
                }
                this.dispose();
                new GymDetailsDisplay(info).setVisible(true);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numeric data.");
            }
        });
        
        JPanel p = new JPanel(); p.add(viewBtn);
        add(p, BorderLayout.SOUTH);
    }
}
//This method displays the gym info in a text area 
class GymDetailsDisplay extends JFrame {
    public GymDetailsDisplay(String infoText) {
        setTitle("Gym Subscription Details");
        setSize(350, 300);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JTextArea area = new JTextArea(infoText);
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.BOLD, 14));
        area.setMargin(new Insets(10, 10, 10, 10));

        add(new JScrollPane(area), BorderLayout.CENTER);

        JButton back = new JButton("Back to Menu");
        //Action listner
        back.addActionListener(e -> {
            this.dispose();
            new MenuWindow().setVisible(true);
        });
        
        JPanel p = new JPanel(); p.add(back);
        add(p, BorderLayout.SOUTH);
    }
}
//View booking window
class Case5Window extends JFrame {
    public Case5Window(Resident res) {
        setTitle("Receipt");
        setSize(450, 500);
        setLocationRelativeTo(null);
        
       
        String summary = "==============================\n" +

                             "      JLA HOTEL RECEIPT       \n" +

                             "==============================\n\n" +

                             "GUEST INFO:\n" +

                             "Name: " + res.getName() + "\n" +

                             "ID: " + res.getId() + "\n" +

                             "Phone: " + res.getPhoneNum() + "\n\n" +
                             
                             "GYM STATUS:\n" +

                             res.viewSub() + "\n\n" +

                             "==============================" ;

        JTextArea area = new JTextArea(summary);
        area.setFont(new Font("Monospaced", Font.PLAIN, 14));
        add(new JScrollPane(area));

        JButton back = new JButton("Back");
        back.addActionListener(e -> { this.dispose(); new MenuWindow().setVisible(true); });
        add(back, BorderLayout.SOUTH);
    }
}